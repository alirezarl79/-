# ساخت APK اندروید ماشین حساب

## راه اول: بدون نصب هیچ چیز (ساخت روی GitHub)
1. در github.com یک حساب و یک مخزن (Repository) جدید بسازید.
2. همه‌ی فایل‌های این پوشه را (شامل پوشه‌ی مخفی `.github`) در مخزن آپلود کنید.
3. به تب **Actions** بروید، workflow با نام **Build APK** را انتخاب و **Run workflow** بزنید.
4. حدود ۵ تا ۱۰ دقیقه صبر کنید. بعد از تمام‌شدن، از پایین صفحه‌ی همان اجرا فایل **calculator-apk** را دانلود کنید. داخلش `app-debug.apk` است.
5. فایل را به گوشی منتقل کنید و باز کنید. اگر اندروید پرسید، اجازه‌ی «نصب از منابع ناشناس» را بدهید.

## راه دوم: روی کامپیوتر خودتان
پیش‌نیاز: Node.js 20 و Android Studio (به‌همراه JDK 17)

    npm install
    npx cap add android
    npx cap sync android
    npx cap open android

در Android Studio از منوی Build > Build APK(s) استفاده کنید.
فایل خروجی: `android/app/build/outputs/apk/debug/app-debug.apk`

## نکته
این APK از نوع debug است و برای نصب روی گوشی خودتان و دوستانتان کافی است.
برای انتشار در گوگل‌پلی یا بازارهای ایرانی باید نسخه‌ی release را با کلید امضای اختصاصی بسازید.
